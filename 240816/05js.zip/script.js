// let pets = ["dog", "cat", "mouse"];
// // "" : 형변환 장치 문자아님!!;
// pets[0] = "hamster"; // dog가 hamster로 바뀜
// // 접근이 가능하면 제어가 가능하다. 배열값 수정!
// console.log(pets);

const colors = ["red", "green", "blue", "white", "black"];

for() {

}


// **********배열에서 값을 수정하는 방법!!**********
// (ex)
// let pets = ["dog", "cat", "mouse"];
// // "" : 형변환 장치 문자아님!!;
// pets[0] = "hamster"; // dog가 hamster로 바뀜
// // 접근이 가능하면 제어가 가능하다. 배열값 수정!
// console.log(pets);

// //배열 => 이터러블 객체
// // 이ㅓㅌ레이터 요소!
// // 제너레이터 // map & set

// 반복문

// for // for of // forEach