//상품전용 자바스크립트 //
const products = {
  data: [
    {
      id: Date.now(),
      name: "Cup",
      price: "17592",
      category: "cold",
      img: "./img/kurly-item1.JPG",
    },
    {
      id: Date.now() + 1,
      name: "Mouse",
      price: "15000",
      category: "daily",
      img: "./img/kurly-item5.JPG",
    },
    {
      id: Date.now() + 2,
      name: "Keybord",
      price: "21000",
      category: "kitchen",
      img: "./img/kurly-item4.JPG",
    },
    {
      id: Date.now() + 3,
      name: "Book",
      price: "21000",
      category: "health",
      img: "./img/kurly-item2.JPG",
    },
    {
      id: Date.now() + 4,
      name: "Pen",
      price: "17592",
      category: "frozen",
      img: "./img/kurly-item3.JPG",
    },
  ],
};

export default products;
