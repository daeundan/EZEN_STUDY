let userNumber = prompt(
  "100개 이하의 자연수 3개를 입력해보세요. 그중 가장 작은 값을 찾아볼게요"
);

if (userNumber !== null && userNumber !== "") {
  let numbers = userNumber.split(/[\s,]+/).map(Number);
  let isValid =
    numbers.length === 3 &&
    numbers.every((num) => Number.isInteger(num) && num > 0 && num <= 100);
  if (isValid) {
    let minValue = Math.min(...numbers);
    alert(`가장 작은 값은 ${minValue}입니다. 맞나요?`);
  } else {
    alert("잘못 입력하셨습니다. 100 이하의 자연수 3개를 입력해주세요");
  }
} else {
  alert("입력이 취소되었습니다 :(");
}

// let userNumber = prompt(
//   "100개 이하의 자연수 3개를 입력하세요. 그중 가장 작은 값을 찾아볼게요."
// );
// let minValue = Math.min(...numbers);

// if ((userNumber !== length) === 3 && numbers.every(Number.isInteger)) {
//   userNumber = parseInt(userNumber);
//   alert(`가장 작은 값은 ${minValue} 입니다`);
// }

// let userNumber =
//   numbers.length === 3 && numbers.every(Number.isInteger) && numbers;
// let minValue = Math.min(...numbers);

// if (isValid) {
//   let minValue = Math.min(...numbers);
//   alert(`${minValue}가 가장 작은 값입니다.`);
// } else if (!isVaid) {
//   alert("잘못된 입력입니다. 다시 입력해주세요.");
//   return;
// }


// let userNumber = prompt("100이하의 자연수 3개를 입력하세요. 그중 가장 작은 값을 맞추어볼게요 :) ");

// let isVaid = numbers.length === 3 && numbers.every(Number.isInteger) && numbers;
// let minValue = Math.min(...numbers);

// if (isValid) {
//   let minValue = Math.min(...numbers);
//   alert(`${minValue}가 가장 작은 값입니다.`)
// } else if (!isVaid) 
//   alert("잘못된 입력입니다. 다시 입력해주세요");
//   return;


// if (!Number.isInteger(parseInt(userNumber))) || parseInt(userNumber) < 3 ||
// parseInt(userNumber) > 100 {
//   console.log("userNumber");
//   return;
// }